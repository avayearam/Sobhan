package com.example.sobhan_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
